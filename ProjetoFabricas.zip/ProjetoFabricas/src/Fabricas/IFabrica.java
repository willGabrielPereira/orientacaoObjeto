/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fabricas;

import java.util.List;

/**
 *
 * @author rodriguh
 */
public interface IFabrica {
    public List<?> criarLista(String url);
}
